package singlylinkedlist;
class Node {
		    int data;
		    Node next;

		    public Node(int data) {
		        this.data = data;
		        this.next = null;
		    }
		}

		class LinkedList {
		    Node head;

		    public LinkedList() {
		        this.head = null;
		    }

		    // Method to insert a new node at the end of the linked list
		    public void insert(int data) {
		        Node newNode = new Node(data);

		        if (head == null) {
		            head = newNode;
		        } else {
		            Node current = head;
		            while (current.next != null) {
		                current = current.next;
		            }
		            current.next = newNode;
		        }
		    }

		    // Method to delete the first occurrence of a key in the linked list
		    public void delete(int key) {
		        if (head == null) {
		            System.out.println("Linked list is empty.");
		            return;
		        }

		        if (head.data == key) {
		            head = head.next;
		            return;
		        }

		        Node current = head;
		        Node prev = null;
		        while (current != null && current.data != key) {
		            prev = current;
		            current = current.next;
		        }

		        if (current == null) {
		            System.out.println("Key not found in the linked list.");
		            return;
		        }

		        prev.next = current.next;
		    }

		    // Method to display the elements of the linked list
		    public void display() {
		        if (head == null) {
		            System.out.println("Linked list is empty.");
		            return;
		        }

		        Node current = head;
		        while (current != null) {
		            System.out.print(current.data + " ");
		            current = current.next;
		        }
		        System.out.println();
		    }
		}

		public class singlyLinkedList {
		    public static void main(String[] args) {
		        LinkedList list = new LinkedList();
		        list.insert(101);
		        list.insert(201);
		        list.insert(301);
		        list.insert(401);
		        list.insert(501);

		        System.out.println("Linked List before deletion:");
		        list.display();

		        int key = 301;
		        list.delete(key);
		        System.out.println("Linked List after deleting " + key + ":");
		        list.display();
		    }
		

	}


