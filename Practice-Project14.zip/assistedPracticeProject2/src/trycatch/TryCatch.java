package trycatch;

public class TryCatch {

public static void main(String[] args) {
		        int[] numbers = { 1, 2, 3, 4, 5 };
		        int index = 10;
                 //it tries to show what possible errors can occur
		        try {
		            int result = numbers[index];
		            System.out.println("The number at index " + index + " is: " + result);
		        } catch (ArrayIndexOutOfBoundsException e) {
		            System.out.println("An exception occurred: " + e.getMessage());
		        } 
		}
}


