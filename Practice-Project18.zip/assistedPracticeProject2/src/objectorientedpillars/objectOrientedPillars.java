package objectorientedpillars;

class BankAccount {
    private String accountNumber;
    private double balance;

    // Constructor
    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Encapsulation 
    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    // Polymorphism 
    @Override
    public String toString() {
        return "Account Number: " + accountNumber + ", Balance: $" + balance;
    }
}
	    
	    public class objectOrientedPillars {
	    public static void main(String[] args) {
	    
	    // Creating objects of BankAccount class
        BankAccount account1 = new BankAccount("12345", 1011.0);
        BankAccount account2 = new BankAccount("36748", 511.0);

        // Accessing object properties using getters
        System.out.println("Account 1 - " + account1.getAccountNumber() + ": $" + account1.getBalance());
        System.out.println("Account 2 - " + account2.getAccountNumber() + ": $" + account2.getBalance());

             
        // Polymorphism 
        System.out.println(account1);
        System.out.println(account2);

	 }
}  
