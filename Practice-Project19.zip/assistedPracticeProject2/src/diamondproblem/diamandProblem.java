package diamondproblem;

	interface A {
	    default void doing() {
	        System.out.println("Doing something in A");
	    }
	}

	interface B extends A {
	    default void doing() {
	        System.out.println("Doing something in B");
	    }
	}

	interface C extends A {
	    default void doing() {
	        System.out.println("Doing something in C");
	    }
	}

	class D implements B, C {
	    public void doing() {
	        B.super.doing(); // this resolves ambiguity by explicitly calling the B's method
	    }
	}

	public class diamandProblem {
	public static void main(String[] args) {
		 D d = new D();
	     d.doing();

	}

}
