package linearsearch;

public class linearSearch {

	public static int linearSearch(int[] arr, int key) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == key) {
                return i; // Return the index where the key is found
            }
        }
        return -1; // Return -1 if the key is not found
    }

	public static void main(String[] args) {
		int[] array = {5, 2, 8, 12, 3, 7};
        int searchKey = 12;

        int index = linearSearch(array, searchKey);
        if (index != -1) {
            System.out.println("Key found at index " + index);
        } else {
            System.out.println("Key not found in the array");
        }
    }


}


