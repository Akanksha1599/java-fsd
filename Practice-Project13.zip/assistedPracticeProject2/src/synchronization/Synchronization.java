package synchronization;
 
 class Table{  
     synchronized void printTable(int n){//this is synchronized method  
         for(int i=1;i<=4;i++){  
    		 System.out.println(n*i);  
    		   try{  
    		      Thread.sleep(40);  
    		     }catch(Exception e){System.out.println(e);}  
    		   }  
    		  
    		 }  
    		}  
    		  
    		public class Synchronization{
    			
    		public static void main(String args[]){  
    			
    		final Table obj = new Table();
    		  
    		Thread t1=new Thread(){  
    		public void run(){  
    		obj.printTable(4);  
    		}  
    		};  
    		Thread t2=new Thread(){  
    		public void run(){  
    		obj.printTable(10);  
    		}  
    		};  
    		  
    		t1.start();  
    		t2.start();  
    		}  
    		  
		} 

  