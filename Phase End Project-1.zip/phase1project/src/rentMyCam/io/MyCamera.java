package rentMyCam.io;
import java.util.ArrayList;
import java.util.Scanner;
public class MyCamera {


		public static void MyCam(ArrayList<Camera> list) {
			
			//an array list is created here which has objects of data type camera
			int MyCamChoice;
			Scanner sc = new Scanner(System.in);
			do {
			//this shows options
			System.out.println("\n1.ADD\n2.REMOVE\n3.VIEW MY CAMERAS\n4.GO TO PREVIOUS MENU\n");
			// this accepts the choices given by user
			MyCamChoice = sc.nextInt();
			// switch is used to work according the choices given by the user
			switch (MyCamChoice) {
			case 1:
				//details are asked from the user
				System.out.println("ENTER THE CAMERA BRAND :\n");
				String brand = sc.next();
				System.out.println("ENTER THE MODEL : \n");
				String model = sc.next();
				System.out.println("ENTER THE PER DAY PRICE :\n");
				int price =sc.nextInt();
				// a method is called to add a new camera
				list.add(new Camera(brand,model,price));
				System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
				break;
				
				
			case 2:
				int i=1;
				System.out.println("CamID\tBrand\tModel\tPrice(per day)\tStatus");
				System.out.println("=============================================================");
				for(Camera c : list) {	
				System.out.println(i+"\t"+c.CamName+"\t"+c.Model+"\t"+c.Rent);
					i=i+1;
				}
				System.out.println("ENTER THE CAMERA ID\n");
				int opt = sc.nextInt();
				list.remove(opt-1);
				System.out.println("CAMERA SUCCESSFULLY REMOVED FROM THE LIST.");
				break;
			case 3:
				i=1;
				System.out.println("CamID\tBrand\tModel\tPrice(per day)\tStatus");
				System.out.println("=============================================================");
				for(Camera c : list) {	
				System.out.println(i+"\t"+c.CamName+"\t"+c.Model+"\t"+c.Rent+"\t\tavailable");
					i=i+1;
				}
				break;
			case 4:
				LoginPage.Menu(list);
				break;
			default:
				throw new IllegalArgumentException("Unexpected value: " + MyCamChoice);
			}}
			while(true);
			
				

	}

}
