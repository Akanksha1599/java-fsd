package arrays;

import java.util.Arrays;

public class arraysimplementation {
	
	public static void main(String[] args) {
		

		        // here array is created
		        int[] numbers = {5, 2, 7, 1, 9};

		        // here length of the array is shown
		        System.out.println("Length of the array: " + numbers.length);

		        // here we are accessing elements of the array
		        System.out.println("First element: " + numbers[0]);
		        System.out.println("Third element: " + numbers[2]);

		        // here we are modifying elements of the array
		        numbers[1] = 8;
		        System.out.println("Modified array: " + Arrays.toString(numbers));

		        // here we are  iterating over the array
		        System.out.print("Array elements: ");
		        for (int i = 0; i < numbers.length; i++) {
		            System.out.print(numbers[i] + " ");
		        }

	}

}
