package exceptionhandling;

public class ExceptionHandling {

	public static void main(String[] args) {
		 
		    try {
            //try shows which error can possibly happen
            int result = divide(10, 0);
            System.out.println("Result: " + result);
            } catch (ArithmeticException e) {
            System.out.println("An exception occurred: " + e.getMessage());}
	}
		public static int divide(int num1, int num2) {
	        return num1 / num2;
	}  
}


