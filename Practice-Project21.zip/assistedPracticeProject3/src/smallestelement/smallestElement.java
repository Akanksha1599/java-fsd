package smallestelement;
import java.util.Arrays;
import java.util.List;
public class smallestElement {

public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(10, 5, 8, 2, 9, 1, 7, 3, 6, 4);
		        int fourthSmallest = findFourthSmallest(numbers);
		        System.out.println("The fourth smallest element is: " + fourthSmallest);
		    }

		    public static int findFourthSmallest(List<Integer> numbers) {
		        if (numbers.size() < 4) {
		            throw new IllegalArgumentException("List should have at least four elements.");
		        }

		        Integer[] sortedArray = numbers.toArray(new Integer[0]);
		        Arrays.sort(sortedArray);

		        return sortedArray[3];  // Index 3 corresponds to the fourth smallest element
		    }
		

	}


