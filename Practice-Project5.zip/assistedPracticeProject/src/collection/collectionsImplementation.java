package collection;
import java.util.*;  
import java.util.Collection;

public class collectionsImplementation {
	  
	public static void main(String args[]){ 
		
	ArrayList<String> list=new ArrayList<String>();//Creating array list 
	
	list.add("Akanksha"); 
	list.add("Kriti");  
	list.add("Aman");  
	list.add("Akash");  
	
	
	Iterator itr=list.iterator();  
	while(itr.hasNext()){  
	System.out.println(itr.next());  
	}  
  }  
}  

	