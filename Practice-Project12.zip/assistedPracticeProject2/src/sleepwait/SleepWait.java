package sleepwait;

public class SleepWait {

		    private static Object obj = new Object();   
		    
		    public static void main(String[] args)throws InterruptedException   
		    {   
		         // process paused for 3 sec
		        Thread.sleep(3000);   
		           
		        System.out.println( Thread.currentThread().getName() +   
		        " Thread is woke after three second");   
		            
		        synchronized (obj)    
		        {   
		            //use wait() method to set obj in waiting state for three seconds  
		            obj.wait(3000);   
		  
		            System.out.println(obj + " Object is in waiting state and woke after 3 seconds");   
		        }   
		 }   
} 
     
	


