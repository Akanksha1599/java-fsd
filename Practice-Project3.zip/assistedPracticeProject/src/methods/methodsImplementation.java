package methods;

import java.util.*;

 public class methodsImplementation {
	 
	public static void main(String args[])   {
	   
	int a; 
	//here we are calling static method of the Math class  
	a=Math.min(24,100);  
	System.out.println("Minimum number is: " + a);
	
	int b;      
	Object obj=new Object();      
	b=obj.hashCode(); //here predefined method is called 
	System.out.println("Hash Code of the object is: "+b);  

    }
}
