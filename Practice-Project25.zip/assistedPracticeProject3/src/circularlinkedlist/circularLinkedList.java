package circularlinkedlist;
class Node {
		    int data;
		    Node next;

		    Node(int data) {
		        this.data = data;
		        this.next = null;
		    }
		}

		class SortedCircularLinkedList {
		    Node head;

		    SortedCircularLinkedList() {
		        this.head = null;
		    }

		    // Method to insert a new element into the sorted circular linked list
		    void insert(int value) {
		        Node newNode = new Node(value);

		        if (head == null) { // If the list is empty
		            head = newNode;
		            head.next = head; // Point to itself since it's a circular list
		        } else if (value <= head.data) { // If the new element is smaller or equal to the head
		            newNode.next = head;
		            Node last = getLastNode();
		            last.next = newNode;
		            head = newNode;
		        } else {
		            Node current = head;
		            while (current.next != head && current.next.data < value) {
		                current = current.next;
		            }

		            newNode.next = current.next;
		            current.next = newNode;
		        }
		    }

		    // Utility method to get the last node of the circular linked list
		    Node getLastNode() {
		        Node current = head;
		        while (current.next != head) {
		            current = current.next;
		        }
		        return current;
		    }

		    // Method to display the elements of the sorted circular linked list
		    void display() {
		        if (head == null) {
		            System.out.println("List is empty");
		            return;
		        }

		        Node current = head;
		        do {
		            System.out.print(current.data + " ");
		            current = current.next;
		        } while (current != head);

		        System.out.println();
		    }
		}

		public class circularLinkedList {
		    public static void main(String[] args) {
		        SortedCircularLinkedList list = new SortedCircularLinkedList();

		        // Inserting elements into the sorted circular linked list
		        list.insert(5);
		        list.insert(10);
		        list.insert(2);
		        list.insert(8);
		        list.insert(15);

		        // Displaying the sorted circular linked list
		        list.display();
		    }
		

	}


