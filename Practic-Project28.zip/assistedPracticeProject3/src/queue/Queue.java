package queue;
import java.util.LinkedList;
import java.util.Queue;

public class Queue {

	public static void main(String[] args) {
		Queue<String> queue = new LinkedList<>();

        // Insert elements into the queue
        queue.add("Element 1");
        queue.add("Element 2");
        queue.add("Element 3");

        System.out.println("Queue elements: " + queue);

        // Remove the element at the front of the queue
        String removedElement = queue.poll();
        System.out.println("Removed element: " + removedElement);

        System.out.println("Queue elements after removal: " + queue);
    }
}

	
	