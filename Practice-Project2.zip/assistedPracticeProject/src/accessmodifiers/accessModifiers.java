package accessmodifiers;

public class accessModifiers {

		    public static void main(String[] args) {
		    	
		        // Create an instance of the ExampleClass
		        ExampleClass example = new ExampleClass();

		        // Access public members
		        example.publicMethod(); 
		        System.out.println(example.publicVariable); 

		        // Access protected members
		        example.protectedMethod(); 
		        System.out.println(example.protectedVariable);
		        
		        //Access default members
		        example.defaultMethod(); 
		        System.out.println(example.defaultVariable); 

		        
		    }
		}

		class ExampleClass {
		    public String publicVariable = "This is a public variable";
		    protected String protectedVariable = "This is a protected variable";
		    String defaultVariable = "This is a default variable";
		    private String privateVariable = "This is a private variable";

		    public void publicMethod() {
		        System.out.println("This is a public method");
		    }

		    protected void protectedMethod() {
		        System.out.println("This is a protected method");
		    }

		    void defaultMethod() {
		        System.out.println("This is a default method");
		    }

		    private void privateMethod() {
		        System.out.println("This is a private method");
		    }
		

	}


