package throwthrows;

	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;

	// Custom exception
	class CustomException extends Exception {
	    public CustomException(String message) {
	        super(message);
	    }
	}

	public class ThrowThrows {
	    public static void main(String[] args) {
	        try {
	            readFile("file.txt");
	            throwCustomException();
	        } catch (FileNotFoundException e) {
	            System.out.println("File not found: " + e.getMessage());
	        } catch (IOException e) {
	            System.out.println("I/OException occurred: " + e.getMessage());
	        } catch (CustomException e) {
	            System.out.println("CustomException occurred: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block is executed here");
	        }
	    }

	    // method that will throw FileNotFoundException
	    public static void readFile(String fileName) throws FileNotFoundException {
	        FileReader fileReader = new FileReader(fileName);
	        // ...
	    }

	    // method that will throw CustomException
	    public static void throwCustomException() throws CustomException {
	        throw new CustomException("This is custom exception.");
	    }
}

