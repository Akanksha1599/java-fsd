public class Calculator {

	public int calculate(int a, int b) {
		return a + b;
	}
}