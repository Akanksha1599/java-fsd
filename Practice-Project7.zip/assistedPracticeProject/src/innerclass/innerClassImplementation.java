package innerclass;

class Outer {
	
    // nested inner class
    class Inner {
 
        public void show()
        {
            System.out.println("I'm in a nested class method");
        }
    }
}

public class innerClassImplementation {
	
	public static void main(String[] args) {
		// inner class object is created inside
        Outer.Inner in = new Outer().new Inner();
        // calling show() method
        in.show();

	}

}
