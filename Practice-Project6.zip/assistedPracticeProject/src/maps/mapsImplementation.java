package maps;

import java.util.*;

public class mapsImplementation {
	public static void main(String[] args)
    {
  
        // Hash map is created
        Map<String, Integer> map = new HashMap<>();
  
        // entries are inserted
        map.put("Akanksha", 10);
        map.put("Nidhi", 30);
        map.put("Tara", 20);
  
        for (Map.Entry<String, Integer> e : map.entrySet())
  
            // Printing key-value
            System.out.println(e.getKey() + " "
                               + e.getValue());
    }
}